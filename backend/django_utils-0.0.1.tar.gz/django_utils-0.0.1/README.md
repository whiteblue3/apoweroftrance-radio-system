This project is a part of [whiteblue3/apoweroftrance-radio](https://github.com/whiteblue3/apoweroftrance-radio) project

# How to packaging
python3 setup.py sdist bdist_wheel


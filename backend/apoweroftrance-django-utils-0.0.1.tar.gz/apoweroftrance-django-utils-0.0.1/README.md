This project is a part of [whiteblue3/apoweroftrance-radio-system](https://github.com/whiteblue3/apoweroftrance-radio-system) project

# How to packaging
python3 setup.py sdist bdist_wheel

